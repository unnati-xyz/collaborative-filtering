from distutils.core import setup

setup(name='CollabFilter', version='1.0', description='Package for collaborative filtering', author='Rohit Sharma, Vaibhavi Pai',
      py_modules=['collaborative-filtering'],)
